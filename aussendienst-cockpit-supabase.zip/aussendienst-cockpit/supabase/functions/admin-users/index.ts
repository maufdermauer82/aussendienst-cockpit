// Zugänge verwalten (nur Admins): anlegen, Rolle/Verknüpfung ändern, sperren, Passwort setzen
import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2.45.4";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });
const fail = (error: string, message: string, status = 400) => json({ error, message }, status);

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return fail("method", "Nur POST", 405);

  const url = Deno.env.get("SUPABASE_URL")!;
  const service = createClient(url, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, { auth: { persistSession: false } });
  const token = (req.headers.get("Authorization") || "").replace(/^Bearer\s+/i, "");
  const { data: who, error: whoErr } = await service.auth.getUser(token);
  if (whoErr || !who?.user) return fail("unauthenticated", "Bitte anmelden.", 401);
  const { data: me } = await service.from("profiles").select("*").eq("user_id", who.user.id).maybeSingle();
  if (!me || !me.active || me.role !== "admin") return fail("forbidden", "Nur für Admins.", 403);

  let b: Record<string, unknown>;
  try { b = await req.json(); } catch { return fail("bad_json", "Ungültige Anfrage."); }
  const role = b.role === "admin" ? "admin" : "staff";
  const employeeId = typeof b.employeeId === "string" && b.employeeId.trim() ? b.employeeId.trim() : null;
  const name = String(b.name || "").trim();
  const password = String(b.password || "");

  if (employeeId) {
    const q = service.from("profiles").select("user_id").eq("employee_id", employeeId);
    const { data: taken } = b.action === "update" ? await q.neq("user_id", String(b.id || "")) : await q;
    if (taken && taken.length) return fail("exists", "Dieser Mitarbeiter ist bereits mit einem anderen Zugang verknüpft.", 409);
  }

  if (b.action === "create") {
    const email = String(b.email || "").trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return fail("bad_email", "Bitte eine gültige E-Mail-Adresse angeben.");
    if (password.length < 10) return fail("weak_password", "Passwort braucht mindestens 10 Zeichen.");
    const { data: created, error } = await service.auth.admin.createUser({ email, password, email_confirm: true, user_metadata: { name } });
    if (error || !created.user) {
      const exists = /already|registered|exists/i.test(error?.message || "");
      return fail(exists ? "exists" : "create_failed", exists ? "Für diese E-Mail gibt es schon einen Zugang." : (error?.message || "Anlegen fehlgeschlagen."), exists ? 409 : 400);
    }
    const { error: pErr } = await service.from("profiles").upsert({ user_id: created.user.id, email, name: name || email, role, employee_id: employeeId, active: true });
    if (pErr) return fail("profile_failed", pErr.message, 500);
    return json({ ok: true, id: created.user.id });
  }

  if (b.action === "update") {
    const id = String(b.id || "");
    const active = b.active !== false;
    if (id === me.user_id && (role !== "admin" || !active)) return fail("self", "Du kannst dir selbst nicht die Admin-Rechte entziehen.");
    const { error: pErr } = await service.from("profiles").update({ name, role, employee_id: employeeId, active }).eq("user_id", id);
    if (pErr) return fail("update_failed", pErr.message, 400);
    const attrs: Record<string, unknown> = { ban_duration: active ? "none" : "876000h" };
    if (password) {
      if (password.length < 10) return fail("weak_password", "Passwort braucht mindestens 10 Zeichen.");
      attrs.password = password;
    }
    const { error: aErr } = await service.auth.admin.updateUserById(id, attrs);
    if (aErr) return fail("update_failed", aErr.message, 400);
    return json({ ok: true });
  }

  return fail("bad_action", "Unbekannte Aktion.");
});
